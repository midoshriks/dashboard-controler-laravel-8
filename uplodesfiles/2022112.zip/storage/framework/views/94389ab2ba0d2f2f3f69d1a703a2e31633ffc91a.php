<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="container-xl">
            <!-- Page title -->
            
            <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-header d-print-none">
                <div class="row">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            <?php echo e(display('Smart bucks')); ?>

                        </div>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><?php echo e(display('Home')); ?></a>
                                </li>
                                <li class="breadcrumb-item"><a
                                        href="<?php echo e(route('dashboard.questions.index')); ?>"><?php echo e(display($title)); ?></a></li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <?php echo e(display('Data questions tables')); ?></li>
                            </ol>
                        </nav>
                    </div>
                    <!-- Page title actions -->
                    <div class="col-12 col-md-auto ms-auto d-print-none">
                        <div class="btn-list">
                            <a href="#" class="btn btn-primary d-none d-sm-inline-block" data-bs-toggle="modal"
                                data-bs-target="#modal-large">
                                <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                    viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                    stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                    <line x1="12" y1="5" x2="12" y2="19" />
                                    <line x1="5" y1="12" x2="19" y2="12" />
                                </svg>
                                <?php echo e(display('Create new questions')); ?>

                            </a>
                            
                            <?php echo $__env->make('dashboard.questions.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                            <a href="#" class="btn btn-primary d-sm-none btn-icon" data-bs-toggle="modal"
                                data-bs-target="#modal-large">
                                <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                    viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                    stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                    <line x1="12" y1="5" x2="12" y2="19" />
                                    <line x1="5" y1="12" x2="19" y2="12" />
                                </svg>
                            </a>
                            
                            <span class="d-sm-inline">
                                <a href="<?php echo e(route('dashboard.questions.export')); ?>" class="btn btn-white">
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            class="icon icon-tabler icon-tabler-database-export" width="24"
                                            height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                            fill="none" stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <ellipse cx="12" cy="6" rx="8" ry="3"></ellipse>
                                            <path
                                                d="M4 6v6c0 1.657 3.582 3 8 3a19.84 19.84 0 0 0 3.302 -.267m4.698 -2.733v-6">
                                            </path>
                                            <path
                                                d="M4 12v6c0 1.599 3.335 2.905 7.538 2.995m8.462 -6.995v-2m-6 7h7m-3 -3l3 3l-3 3">
                                            </path>
                                        </svg>
                                    </span>
                                    <?php echo e('download file'); ?>

                                </a>
                                <a href="#" class="btn" data-bs-toggle="modal" data-bs-target="#modal-success">
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-upload"
                                            width="24" height="24" viewBox="0 0 24 24" stroke-width="2"
                                            stroke="currentColor" fill="none" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2"></path>
                                            <polyline points="7 9 12 4 17 9"></polyline>
                                            <line x1="12" y1="4" x2="12" y2="16"></line>
                                        </svg>
                                    </span>
                                    <?php echo e('uplaode file'); ?>

                                </a>
                                
                                <div class="modal modal-blur fade" id="modal-success" tabindex="-1" role="dialog"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                            <div class="modal-status bg-success"></div>
                                            <div class="modal-body text-center py-4">
                                                <!-- Download SVG icon from http://tabler-icons.io/i/circle-check -->
                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                    class="icon mb-2 text-green icon-lg" width="24" height="24"
                                                    viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                                    fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                    <circle cx="12" cy="12" r="9" />
                                                    <path d="M9 12l2 2l4 -4" />
                                                </svg>
                                            </div>
                                            <form action="<?php echo e(route('dashboard.questions.import')); ?>" method="post"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <div class="form-label">File xsls</div>
                                                        <input type="file" name="file" value="1"
                                                            class="form-control" />
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <div class="w-100">
                                                        <div class="row">
                                                            <div class="col"><button type="submit" href="#"
                                                                    class="btn btn-success w-100" data-bs-dismiss="modal">
                                                                    <?php echo e(display('uploade file')); ?>

                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        
                        </span>
                    </div>
                    <div class="btn-list">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="page-body">
        <div class="container-xl">
            <div class="row row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="col-12">
                            <div class="table-responsive">
                                <table id="dataTable" class="table table-vcenter card-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo e(display('name')); ?></th>
                                            <th><?php echo e(display('type')); ?></th>
                                            <th><?php echo e(display('level')); ?></th>
                                            <th><?php echo e(display('answer 1')); ?></th>
                                            <th><?php echo e(display('answer 2')); ?></th>
                                            <th><?php echo e(display('answer 3')); ?></th>
                                            <th><?php echo e(display('answer 4')); ?></th>
                                            <th><?php echo e(display('action')); ?></th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($question->name); ?></td>
                                                <td><?php echo e(display($question->type->name)); ?></td>
                                                <td><?php echo e(display($question->level->name)); ?></td>
                                                <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    <td>
                                                        <div class="datagrid-item">
                                                            <div class="datagrid-content">
                                                                <?php if($answer->correct == 1): ?>
                                                                    <span
                                                                        class="status status-green"><?php echo e($answer->answer); ?></span>
                                                                <?php else: ?>
                                                                    <span
                                                                        class="status status-red"><?php echo e($answer->answer); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <div class="col-auto">
                                                        <div class="dropdown">
                                                            <a href="#" class="btn-action"
                                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                                <!-- Download SVG icon from http://tabler-icons.io/i/dots-vertical -->
                                                                <svg xmlns="http://www.w3.org/2000/svg" class="icon"
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    stroke-width="2" stroke="currentColor" fill="none"
                                                                    stroke-linecap="round" stroke-linejoin="round">
                                                                    <path stroke="none" d="M0 0h24v24H0z"
                                                                        fill="none" />
                                                                    <circle cx="12" cy="12"
                                                                        r="1" />
                                                                    <circle cx="12" cy="19"
                                                                        r="1" />
                                                                    <circle cx="12" cy="5"
                                                                        r="1" />
                                                                </svg>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="<?php echo e(route('dashboard.questions.edit', $question->id)); ?>"
                                                                    class="dropdown-item">Edit</a>

                                                                <a href="javascript:;"
                                                                    class="dropdown-item text-danger btn-delet"
                                                                    data-form-id="question-delete-<?php echo e($question->id); ?>"
                                                                    data-name-item="<?php echo e($question->name); ?>">
                                                                    <?php echo e(display('Delete')); ?>

                                                                </a>

                                                                <form id="question-delete-<?php echo e($question->id); ?>"
                                                                    action="<?php echo e(route('dashboard.questions.destroy', $question->id)); ?>"
                                                                    method="POST" style="display: inline-block;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                </form>
                                                            </div>
                                                        </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/dashboard/questions/index.blade.php ENDPATH**/ ?>