<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        <?php echo e(display('Data grid')); ?> \ <?php echo e(display($user->first_name)); ?>

                    </h2>
                </div>
            </div>
        </div>
    </div>

    <div class="page-body">
        <div class="container-xl">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo e(display('Information' . ' ' . $user->first_name . ' ' . $user->last_name)); ?>

                    </h3>
                </div>
                <div class="card-body">
                    <div class="datagrid">
                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('email user')); ?></div>
                            <div class="datagrid-content">
                                <div class="d-flex align-items-center">
                                    <span class="avatar avatar-xs me-2 avatar-rounded" 
                                        style="background-image: url(<?php echo e($user->getMedia('photo_user')->last()? $user->getMedia('photo_user')->last()->getUrl('mobile'): $user->photo_user); ?>"></span>
                                    <?php echo e($user->email); ?>

                                </div>
                            </div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('name user')); ?></div>
                            <div class="datagrid-content"><?php echo e($user->first_name . ' ' . $user->last_name); ?></div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('Name servers Role')); ?></div>
                            <div class="datagrid-content"><?php echo e($user->role_permissions); ?></div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('code membership')); ?></div>
                            <div class="datagrid-content"><?php echo e($user->code_membership); ?></div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('user gender')); ?></div>
                            <div class="datagrid-content">
                                <div class="datagrid-content">
                                    <?php if($user->gender): ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-man"
                                            width="24" height="24" viewBox="0 0 24 24" stroke-width="2"
                                            stroke="currentColor" fill="none" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <circle cx="12" cy="5" r="2"></circle>
                                            <path d="M10 22v-5l-1 -1v-4a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4l-1 1v5"></path>
                                        </svg>
                                        <?php echo e($user->gender); ?>

                                    <?php else: ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-woman"
                                            width="24" height="24" viewBox="0 0 24 24" stroke-width="2"
                                            stroke="currentColor" fill="none" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <circle cx="12" cy="5" r="2"></circle>
                                            <path d="M10 22v-4h-2l2 -6a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1l2 6h-2v4"></path>
                                        </svg>
                                        <?php echo e($user->gender); ?>

                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('Age')); ?></div>
                            <div class="datagrid-content"><?php echo e($user->dob_date); ?></div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('user continer')); ?></div>
                            <div class="datagrid-content">
                                <div class="datagrid-content">
                                    <?php echo e($user->country->name); ?>

                                </div>
                            </div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('user phone')); ?></div>
                            <div class="datagrid-content">
                                <div class="datagrid-content">
                                    <?php echo e($user->phone); ?>

                                </div>
                            </div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('Checked phone verified')); ?></div>
                            <div class="datagrid-content">
                                <?php if($user->phone_verified_at == null): ?>
                                    <div class="datagrid-content">
                                        <span class="status status-red"><?php echo e(display('X')); ?></span>
                                        <?php echo e(display('Non-Checked')); ?>

                                    </div>
                                <?php else: ?>
                                    <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon text-green" width="24"
                                        height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                        fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                        <path d="M5 12l5 5l10 -10" />
                                    </svg>
                                    <?php echo e(display('Checked')); ?>

                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('user status')); ?></div>
                            <div class="datagrid-content">
                                <?php if($user->status == 1): ?>
                                    <span class="status status-green"><?php echo e(display('Active')); ?></span>
                                <?php else: ?>
                                    <span class="status status-red"><?php echo e(display('Non-Active')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">Avatars list</div>
                            <div class="datagrid-content">
                                <?php $__currentLoopData = $levels_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="avatar-list avatar-list-stacked">
                                        <span class="avatar avatar-xs avatar-rounded"
                                            style="background-image: url(<?php echo e($level_user->getMedia('photo_level')->last()? $level_user->getMedia('photo_level')->last()->getUrl('mobile'): $level_user->photo_user); ?>)"></span>
                                        <span class="avatar avatar-xs avatar-rounded"><?php echo e($level_user->name); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('user level')); ?></div>
                            <div class="datagrid-content">
                                <div class="datagrid-content">
                                    <?php $__currentLoopData = $levels_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($level_user->name); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title">Expiration date</div>
                            <div class="datagrid-content">–</div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title"><?php echo e(display('Age')); ?></div>
                            <div class="datagrid-content"><?php echo e($user->dob_date); ?></div>
                        </div>

                        <div class="datagrid-item">
                            <div class="datagrid-title">Form control</div>
                            <div class="datagrid-content">
                                <input type="text" class="form-control form-control-flush"
                                    placeholder="Input placeholder">
                            </div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">Longer description</div>
                            <div class="datagrid-content">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/dashboard/users/show.blade.php ENDPATH**/ ?>