<div class="modal modal-blur fade" id="modal-large" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e(display('create users')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header mr-lg-5">
                            <h3 class="card-title"><?php echo e(display('Form Admin or User ')); ?></h3>
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user-plus"
                                width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <circle cx="9" cy="7" r="4"></circle>
                                <path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path>
                                <path d="M16 11h6m-3 -3v6"></path>
                            </svg>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('dashboard.users.store')); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('post')); ?>


                                <div class="form-group mb-3 col-md-12 d-flex">
                                    <div class="col-md-12">
                                        <label class="form-label required"><?php echo e(display('first name')); ?></label>
                                        <div class="">
                                            <input type="text" class="form-control" name="first_name"
                                                value="firts name" placeholder="Enter First name">
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group mb-3 col-md-12 d-flex">
                                    <div class="col-md-12">
                                        <label class="form-label required"><?php echo e(display('last name')); ?></label>
                                        <div>
                                            <input type="text" class="form-control" name="last_name"
                                                value="last name" placeholder="Enter last name">
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group mb-3 col-md-12 d-flex">
                                    <div class="col-md-12">
                                        <label class="form-label required"><?php echo e(display('Phone user')); ?></label>
                                        <div>
                                            <input type="number" class="form-control" name="phone" value="012000000"
                                                placeholder="+020--- -- --">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group mb-3 col-md-12 d-flex">
                                    <div class="col-md-12">
                                        <label class="form-label required"><?php echo e(display('date of birth')); ?></label>
                                        <input type="date" name="dob_date" id="" class="form-control">
                                    </div>
                                </div>

                                <div class="form-group mb-3 col-md-12 d-flex">
                                    <div class="col-md-12">
                                        <div>
                                            <div class="mb-3">
                                                <div class="form-label"><?php echo e(display('Select Role')); ?></div>
                                                <select class="form-select" name="role_permissions">
                                                    <option value="">chooes</option>
                                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($type->name); ?>"><?php echo e(display($type->name)); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group mb-3 col-md-12 d-flex">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <div class="form-label"><?php echo e(display('Select gender')); ?></div>
                                            <select class="form-select" name="gender">
                                                <option value=""><?php echo e(display('chooes')); ?></option>
                                                <option value="male"><?php echo e(display('male')); ?></option>
                                                <option value="famle"><?php echo e(display('famle')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <div class="mb-3">
                                        <div class="form-label"><?php echo e(display('Select nation')); ?></div>
                                        <select class="form-select" name="country_id">
                                            <option value=""><?php echo e(display('chooes')); ?></option>
                                            <?php $__currentLoopData = $select_countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $select_country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($select_country->id); ?>"><?php echo e($select_country->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group mb-3 ">
                                    <label class="form-label required"><?php echo e(display('Email address')); ?></label>
                                    <div>
                                        <input type="email" class="form-control" aria-describedby="emailHelp"
                                            name="email" placeholder="Enter email">
                                        <small
                                            class="form-hint"><?php echo e(display("We'll never share your email with anyone else.")); ?></small>
                                    </div>
                                </div>
                                <div class="form-group mb-3 ">
                                    <label class="form-label required"><?php echo e(display('Password')); ?></label>
                                    <div>
                                        <input type="password" class="form-control" placeholder="Password"
                                            name="password">
                                        <small class="form-hint">
                                            <?php echo e(display('Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.')); ?>

                                        </small>
                                    </div>
                                </div>

                                <div class="form-group mb-3 ">
                                    <label class="form-label required"><?php echo e(display('Re Password')); ?></label>
                                    <div>
                                        <input type="password" class="form-control" placeholder="Retype Password"
                                            name="password_confirmation">
                                    </div>
                                </div>

                                <div class="form-group mb-3 ">
                                    <label class="form-label required"><?php echo e(display('image user')); ?></label>
                                    <div>
                                        <input type="file" class="form-control" name="image">
                                    </div>
                                </div>


                                <?php
                                    $models = ['users', 'qoution'];
                                    $maps = ['create', 'read', 'update', 'delete'];
                                ?>

                                <div class="col-md-12">
                                    <div class="card">
                                        <ul class="nav nav-tabs" data-bs-toggle="tabs">
                                            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="nav-item">
                                                    <a href="#<?php echo e($model); ?>"
                                                        class="nav-link <?php echo e($index == 0 ? 'active' : ''); ?>"
                                                        data-bs-toggle="tab"><?php echo e($model); ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>

                                        <div class="card-body">
                                            <div class="tab-content">
                                                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="tab-pane fade <?php echo e($index == 0 ? 'active' : ''); ?> show"
                                                        id="<?php echo e($model); ?>">
                                                        <?php $__currentLoopData = $maps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $map): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <label style="margin-right: 20px;">
                                                                <input type="checkbox" name="permissions[]"
                                                                    value="<?php echo e($model . '_' . $map); ?>" id="">
                                                                <?php echo e($model . ' ' . $map); ?>

                                                            </label>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn me-auto" data-bs-dismiss="modal"><?php echo e(display('Close')); ?></button>
                <button type="submit" class="btn btn-primary"
                    data-bs-dismiss="modal"><?php echo e(display('Save')); ?></button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/dashboard/users/create.blade.php ENDPATH**/ ?>