<!-- Tabler Core -->
<script src="<?php echo e(asset('dashboard/dist/js/tabler.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('dashboard/dist/js/demo.min.js')); ?>" defer></script>

<!-- Libs JS -->
<script src="<?php echo e(asset('dashboard/dist/libs/apexcharts/dist/apexcharts.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('dashboard/dist/libs/jsvectormap/dist/js/jsvectormap.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('dashboard/dist/libs/jsvectormap/dist/maps/world.js')); ?>" defer></script>
<script src="<?php echo e(asset('dashboard/dist/libs/jsvectormap/dist/maps/world-merc.js')); ?>" defer></script>



<script src="<?php echo e(asset('dashboard/src/js/sweet-alert/jquery.min.js')); ?>"></script>
<!-- sweet alerts -->
<script src="<?php echo e(asset('dashboard/src/js/sweet-alert/sweet-alert.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/src/js/sweet-alert/sweet-alert.init.js')); ?>"></script>




<script type="text/javascript" src="<?php echo e(asset('dashboard/datatables/datatables.min.js')); ?>"></script>





<script>
    $(document).ready(function() {
        $('#dataTable').DataTable();
    });
</script>

<?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/layouts/dashboard/script.blade.php ENDPATH**/ ?>