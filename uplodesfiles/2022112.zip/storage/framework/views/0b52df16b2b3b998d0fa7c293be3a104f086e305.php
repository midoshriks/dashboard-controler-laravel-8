<?php $__env->startSection('content'); ?>
    
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <div class="page-pretitle">
                        <?php echo e(display('Smart bucks')); ?>

                    </div>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><?php echo e(display('Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(route('dashboard.users.index')); ?>"><?php echo e(display('users')); ?></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(display('Data users tables')); ?></li>
                        </ol>
                    </nav>
                </div>
                <!-- Page title actions -->
                <div class="col-12 col-md-auto ms-auto d-print-none">
                    <div class="btn-list">
                        
                        <a href="#" class="btn btn-primary d-none d-sm-inline-block" data-bs-toggle="modal"
                            data-bs-target="#modal-large">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <line x1="12" y1="5" x2="12" y2="19" />
                                <line x1="5" y1="12" x2="19" y2="12" />
                            </svg>
                            Create new user
                        </a>
                        
                        <?php echo $__env->make('dashboard.users.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                        <a href="#" class="btn btn-primary d-sm-none btn-icon" data-bs-toggle="modal"
                            data-bs-target="#modal-large">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <line x1="12" y1="5" x2="12" y2="19" />
                                <line x1="5" y1="12" x2="19" y2="12" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="page-body">
        <div class="container-xl">
            <div class="row row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-vcenter card-table">
                                <thead>
                                    <tr>
                                        <th><?php echo e(display('Name')); ?></th>
                                        <th><?php echo e(display('Title')); ?></th>
                                        <th><?php echo e(display('Role')); ?></th>
                                        <th><?php echo e(display('Status')); ?></th>
                                        <th><?php echo e(display('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex py-1 align-items-center">
                                                    <span class="avatar me-2">
                                                        <img src="<?php echo e($user->getMedia('photo_user')->last()? $user->getMedia('photo_user')->last()->getUrl('mobile'): $user->photo_user); ?>"
                                                            alt="">
                                                    </span>
                                                    <div class="flex-fill">
                                                        <div class="font-weight-medium"><?php echo e($user->first_name); ?>

                                                        </div>
                                                        <div class="text-muted"><a
                                                                href="<?php echo e(route('dashboard.users.show', $user->id)); ?>"
                                                                class="text-reset"><?php echo e($user->email); ?></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div><?php echo e($user->phone); ?></div>
                                                <div class="text-muted"><?php echo e($user->country->name); ?></div>
                                            </td>
                                            <td class="text-muted">
                                                
                                                <?php if($user->role_permissions == 'super_admin'): ?>
                                                    <?php echo e($user->role_permissions == 'super_admin' ? 'Owner' : 'Admin'); ?>

                                                <?php elseif($user->role_permissions == 'gaming'): ?>
                                                    <?php echo e($user->role_permissions == 'gaming' ? 'Gaming' : 'Admin'); ?>

                                                <?php else: ?>
                                                    <?php echo e($user->role_permissions == 'developer' ? 'Developer' : 'Admin'); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                
                                                <div class="mb-3">
                                                    <label class="form-check form-switch">
                                                        <!-- Rounded switch -->
                                                        <label class="switch">
                                                            <input class="form-check-input btn-active" type="checkbox"
                                                                <?php echo e($user->status == 1 ? 'checked' : ''); ?>

                                                                data-form-id="user-active-<?php echo e($user->id); ?>"
                                                                data-name-item="<?php echo e($user->first_name); ?>">
                                                        </label>
                                                        
                                                        <form id="user-active-<?php echo e($user->id); ?>" style="display: none"
                                                            action="<?php echo e(route('dashboard.user.active', $user->id)); ?>"
                                                             method="POST"
                                                            style="display: inline-block;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <input name="status" value="<?php echo e($user->status == 1 ? 0 : 1); ?>">
                                                            <input type="submit" value="save">
                                                        </form>
                                                        
                                                        
                                                        
                                                        
                                                    </label>
                                                </div>
                                                
                                            </td>
                                            <td>
                                                <div class="col-auto">
                                                    <div class="dropdown">
                                                        <a href="#" class="btn-action" data-bs-toggle="dropdown"
                                                            aria-expanded="false">
                                                            <!-- Download SVG icon from http://tabler-icons.io/i/dots-vertical -->
                                                            <svg xmlns="http://www.w3.org/2000/svg" class="icon"
                                                                width="24" height="24" viewBox="0 0 24 24"
                                                                stroke-width="2" stroke="currentColor" fill="none"
                                                                stroke-linecap="round" stroke-linejoin="round">
                                                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                                <circle cx="12" cy="12" r="1" />
                                                                <circle cx="12" cy="19" r="1" />
                                                                <circle cx="12" cy="5" r="1" />
                                                            </svg>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="<?php echo e(route('dashboard.users.edit', $user->id)); ?>"
                                                                class="dropdown-item">Edit</a>
                                                            

                                                            <a href="javascript:;"
                                                                class="dropdown-item text-danger btn-delet"
                                                                data-form-id="user-delete-<?php echo e($user->id); ?>"
                                                                data-name-item="<?php echo e($user->first_name); ?>">
                                                                Delete
                                                            </a>

                                                            <form id="user-delete-<?php echo e($user->id); ?>"
                                                                action="<?php echo e(route('dashboard.users.destroy', $user->id)); ?>"
                                                                method="POST" style="display: inline-block;">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                            </form>

                                                            
                                                        </div>
                                                    </div>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    

    
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/dashboard/users/index.blade.php ENDPATH**/ ?>