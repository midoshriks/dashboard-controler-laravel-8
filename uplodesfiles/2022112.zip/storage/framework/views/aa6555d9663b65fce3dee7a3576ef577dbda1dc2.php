<table class="table table-vcenter card-table text-center">
    <thead>
        <tr>
            <th>#</th>
            <th>question</th>
            <th>type</th>
            <th>level</th>
            <th>answer_1</th>
            <th>answer_2</th>
            <th>answer_3</th>
            <th>answer_4</th>
            <th>correct</th>
            <th class="w-1"></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($question->name); ?></td>
                <td><?php echo e(display($question->type->name)); ?></td>
                <td><?php echo e(display($question->level->name)); ?></td>
                <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td>
                        <?php echo e($answer->answer); ?>

                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <td>
                    <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($answer->correct == 1 ? $index + 1 : ''); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/dashboard/questions/export.blade.php ENDPATH**/ ?>