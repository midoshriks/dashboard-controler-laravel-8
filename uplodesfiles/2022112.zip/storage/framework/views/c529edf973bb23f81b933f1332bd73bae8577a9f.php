<div class="modal modal-blur fade" id="modal-large" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e(display('create level')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header mr-lg-5">
                            <h3 class="card-title m-1"><?php echo e(display('form levels')); ?></h3>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-list-check"
                                    width="24" height="24" viewBox="0 0 24 24" stroke-width="2"
                                    stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path d="M3.5 5.5l1.5 1.5l2.5 -2.5"></path>
                                    <path d="M3.5 11.5l1.5 1.5l2.5 -2.5"></path>
                                    <path d="M3.5 17.5l1.5 1.5l2.5 -2.5"></path>
                                    <line x1="11" y1="6" x2="20" y2="6"></line>
                                    <line x1="11" y1="12" x2="20" y2="12"></line>
                                    <line x1="11" y1="18" x2="20" y2="18"></line>
                                </svg>
                            </span>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('dashboard.levels.store')); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('post')); ?>

                                <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <div class="form-group mb-3 col-md-12 d-flex">
                                    <div class="col-sm-6 m-1">
                                        <label class="form-label required"><?php echo e(display('name level')); ?></label>
                                        <div class="">
                                            <input type="text" class="form-control" name="name" value="one"
                                                placeholder="Enter level name">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 m-1">
                                        <label class="form-label required"><?php echo e(display('rewards level')); ?></label>
                                        <div>
                                            <input type="text" class="form-control" name="rewards" value="$1000"
                                                placeholder="Enter rewards level ">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group mb-3 ">
                                    <label class="form-label required"><?php echo e(display('image user')); ?></label>
                                    <div>
                                        <input type="file" class="form-control" name="image">
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn me-auto" data-bs-dismiss="modal"><?php echo e(display('Close')); ?></button>
                <button type="submit" class="btn btn-primary" data-bs-dismiss="modal"><?php echo e(display('Save')); ?></button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/dashboard/levels/create.blade.php ENDPATH**/ ?>