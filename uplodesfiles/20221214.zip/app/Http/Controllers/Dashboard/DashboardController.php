<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\type;
use App\Models\User;
use App\Models\Product;
use App\Models\Question;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\level;
use App\Models\UserLevel;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $total = [
            'admin' => User::where('role_permissions', 'admin')->get(),
            'gaming' => User::where('role_permissions', 'gaming')->get(),
            'questions' => Question::all(),
            'level' => level::all(),

            $coin = type::where('model', 'product')->where('name', 'coin')->first(),
            $helper = type::where('model', 'product')->where('name', 'helper')->first(),
            'coin' => Product::where('type_id', $coin->id)->get(),
            'helper' => Product::where('type_id', $helper->id)->get(),
            // dd($coin),

        ];

        $gaming = type::where('model', 'user')->where('name', 'gaming')->first();
        // $userlevel = UserLevel::groupBy('user_id')->select('user_id', DB::raw('count(*) as total'))->get();
        // $userlevels = UserLevel::groupBy('user_id')->select('user_id', DB::raw('count(*) as total'))->orderBy('user_id')->take(5)->get();

        $first5 = User::where('role_permissions','gaming')->with('levels')->get();

        // dd($first5);

        return view('dashboard.index', compact('total', 'first5'));
    }
}
