<?php $__env->startSection('content'); ?>
    
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <!-- Page pre-title -->
                    <div class="page-pretitle">
                        <?php echo e(display('Overview')); ?>

                    </div>
                    <h2 class="page-title">
                        <?php echo e(display('Dashboard')); ?> \ <?php echo e(display('Users')); ?> \ <?php echo e(display('edit')); ?> \
                        <?php echo e($user->first_name); ?>

                    </h2>
                </div>
            </div>
        </div>
    </div>
    
    <div class="page-body">
        <div class="container-xl">
            <div class="row">
                <div class="col-md-4">
                    <div class="modal-header mb-1">
                        <h5 class="modal-title">
                            <?php echo e($user->role_permissions == 'admin' ? display('edit admin : ') : display('edit user : ')); ?>

                            <?php echo e($user->first_name); ?> </h5>
                    </div>
                </div>
                <div class="row">
                    <div class="modal-content">
                        <div class="col-md-12">
                            <div class="modal-body align-self-center">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title" style="margin-right: 5px;">
                                            <?php echo e(display('form Admin end User ')); ?>

                                        </h3>
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-pencil"
                                            width="24" height="24" viewBox="0 0 24 24" stroke-width="2"
                                            stroke="currentColor" fill="none" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <path d="M4 20h4l10.5 -10.5a1.5 1.5 0 0 0 -4 -4l-10.5 10.5v4"></path>
                                            <line x1="13.5" y1="6.5" x2="17.5" y2="10.5"></line>
                                        </svg>
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            class="icon icon-tabler icon-tabler-user-plus" width="24" height="24"
                                            viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                            <circle cx="9" cy="7" r="4"></circle>
                                            <path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path>
                                            <path d="M16 11h6m-3 -3v6"></path>
                                        </svg>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?php echo e(route('dashboard.users.update', $user->id)); ?>" method="post"
                                            enctype="multipart/form-data">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('PUT')); ?>


                                            <div class="form-group mb-3 col-md-12 d-flex">
                                                <div class="col-sm-6 me-2">
                                                    <label class="form-label required"><?php echo e(display('first name')); ?></label>
                                                    <div class="">
                                                        <input type="text" class="form-control" name="first_name"
                                                            value="<?php echo e($user->first_name); ?>" placeholder="Enter First name">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label class="form-label required"><?php echo e(display('last name')); ?></label>
                                                    <div>
                                                        <input type="text" class="form-control" name="last_name"
                                                            value="<?php echo e($user->last_name); ?>" placeholder="Enter last name">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group mb-3 col-md-12 d-flex">
                                                <div class="col-md-6 me-2">
                                                    <label class="form-label required"><?php echo e(display('Phone user')); ?></label>
                                                    <div>
                                                        <input type="number" class="form-control" name="phone"
                                                            value="<?php echo e($user->phone); ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <label
                                                        class="form-label required"><?php echo e(display('date of birth')); ?></label>
                                                    <input type="date" name="dob_date" id=""
                                                        class="form-control" value="<?php echo e($user->dob_date); ?>">
                                                </div>
                                            </div>

                                            <div class="form-group mb-3 col-md-12 d-flex">
                                                <div class="col-md-6 me-2">
                                                    <div>
                                                        <div class="mb-3">
                                                            <div class="form-label"><?php echo e(display('Select Role')); ?></div>
                                                            <select class="form-select" name="role_permissions">
                                                                <option value=""><?php echo e(display('chooes')); ?></option>
                                                                
                                                                <option
                                                                    <?php echo e($user->role_permissions == $user->role_permissions ? 'selected' : ''); ?>

                                                                    value="<?php echo e($user->role_permissions); ?>">
                                                                    <?php echo e($user->role_permissions); ?></option>
                                                                <option value="gaming"><?php echo e(display('Gaming')); ?></option>
                                                                <option value="admin"><?php echo e(display('Admin')); ?></option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <div class="form-label"><?php echo e(display('Select gender')); ?></div>
                                                        <select class="form-select" name="gender">
                                                            <option value=""><?php echo e(display('chooes')); ?></option>
                                                            <option <?php echo e($user->gender == $user->gender ? 'selected' : ''); ?>

                                                                value="<?php echo e($user->gender); ?>"><?php echo e($user->gender); ?></option>
                                                            <option value="male"><?php echo e(display('male')); ?></option>
                                                            <option value="famle"><?php echo e(display('famle')); ?></option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="mb-3">
                                                    <div class="form-label"><?php echo e(display('Select nation')); ?></div>
                                                    <select class="form-select" name="country_id">
                                                        <option value=""><?php echo e(display('chooes')); ?></option>
                                                        <?php $__currentLoopData = $select_countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $select_country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option
                                                                <?php echo e($select_country->id == $user->country_id ? 'selected' : ''); ?>

                                                                value="<?php echo e($select_country->id); ?>">
                                                                <?php echo e($select_country->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group mb-3 ">
                                                <label class="form-label required"><?php echo e(display('Email address')); ?></label>
                                                <div>
                                                    <input type="email" class="form-control"
                                                        aria-describedby="emailHelp" name="email"
                                                        placeholder="Enter email" value="<?php echo e($user->email); ?>">
                                                    <small
                                                        class="form-hint"><?php echo e(display("We'll never share your email with anyone else.")); ?></small>
                                                </div>
                                            </div>
                                            <div class="form-group mb-3 ">
                                                <label class="form-label required"><?php echo e(display('Password')); ?></label>
                                                <div>
                                                    <input type="password" class="form-control" placeholder="Password"
                                                        name="password" value="<?php echo e($user->password); ?>">
                                                    <small class="form-hint">
                                                        <?php echo e(display('Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.')); ?>

                                                    </small>
                                                </div>
                                            </div>

                                            <div class="form-group mb-3 ">
                                                <label class="form-label required"><?php echo e(display('Re Password')); ?></label>
                                                <div>
                                                    <input type="password" class="form-control"
                                                        placeholder="Retype Password" name=""
                                                        value="<?php echo e($user->password); ?>">
                                                </div>
                                            </div>

                                            <div class="form-group mb-3 ">
                                                <label class="form-label required"><?php echo e(display('image user')); ?></label>
                                                <div>
                                                    <input type="file" class="form-control" name="image">
                                                    <small class="form-hint">
                                                        <img src="<?php echo e($user->getFirstMediaUrl('photo')); ?>" alt=""
                                                            srcset="" width="160">
                                                    </small>
                                                </div>
                                            </div>
                                                
                                            <?php if($user->role_permissions == 'admin' || 'super_admin' || 'developer'): ?>
                                                <?php
                                                    $models = ['users', 'qoutions'];
                                                    $maps = ['create', 'read', 'update', 'delete'];
                                                ?>

                                                <div class="col-md-12">
                                                    <div class="card">
                                                        <ul class="nav nav-tabs" data-bs-toggle="tabs">
                                                            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li class="nav-item">
                                                                    <a href="#<?php echo e($model); ?>"
                                                                        class="nav-link <?php echo e($index == 0 ? 'active' : ''); ?>"
                                                                        data-bs-toggle="tab"><?php echo e($model); ?></a>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>

                                                        <div class="card-body">
                                                            <div class="tab-content">
                                                                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="tab-pane fade <?php echo e($index == 0 ? 'active' : ''); ?> show"
                                                                        id="<?php echo e($model); ?>">
                                                                        <?php $__currentLoopData = $maps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $map): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <label style="margin-right: 20px;">
                                                                                <input type="checkbox" name="permissions[]" <?php echo e($user->hasPermission($model . '_' . $map) ? 'checked' : ''); ?> value="<?php echo e($model . '_' . $map); ?>" id="<?php echo e($model . ' ' . $map); ?>">
                                                                                    <?php echo e($model . ' ' . $map); ?>

                                                                            </label>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                            <div class="form-group mb-1 ">
                                                <div class="modal-footer mt-lg-5">
                                                    <button type="submit" class="btn btn-primary"
                                                        data-bs-dismiss="modal"><?php echo e(display('Update')); ?></button>
                                                </div>
                                            </div>

                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/dashboard/users/edit.blade.php ENDPATH**/ ?>