<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />

    
    <?php if(app()->getLocale() == 'en'): ?>
        <!-- CSS files -->
        <link href="<?php echo e(asset('dashboard/dist/css/tabler.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('dashboard/dist/css/tabler-flags.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('dashboard/dist/css/tabler-payments.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('dashboard/dist/css/tabler-vendors.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('dashboard/dist/css/demo.min.css')); ?>" rel="stylesheet" />
    <?php else: ?>
        <!-- CSS files -->
        <link href="<?php echo e(asset('dashboard/dist/css/tabler.rtl.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('dashboard/dist/css/tabler-flags.rtl.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('dashboard/dist/css/tabler-payments.rtl.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('dashboard/dist/css/tabler-vendors.rtl.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('dashboard/dist/css/demo.rtl.min.css')); ?>" rel="stylesheet" />
    <?php endif; ?>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
</head>

<body>
    <div class="page">
            
            <div class="page-wrapper">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        
        <?php echo $__env->make('layouts.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    
    <?php echo $__env->make('layouts.dashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/layouts/dashboard/material.blade.php ENDPATH**/ ?>