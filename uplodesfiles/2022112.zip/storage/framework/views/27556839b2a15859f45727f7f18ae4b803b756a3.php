<div class="modal modal-blur fade" id="modal-large" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e(display('create products ' . $type)); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header mr-lg-5">
                            <h3 class="card-title m-1"><?php echo e(display('form product ' . $type)); ?></h3>
                            <?php if($type == 'coin'): ?>
                                <span class="nav-link-icon d-md-none d-lg-inline-block">
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                        class="icon icon-tabler icon-tabler-coin-bitcoin" width="24" height="24"
                                        viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                        stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                        <circle cx="12" cy="12" r="9"></circle>
                                        <path
                                            d="M9 8h4.09c1.055 0 1.91 .895 1.91 2s-.855 2 -1.91 2c1.055 0 1.91 .895 1.91 2s-.855 2 -1.91 2h-4.09">
                                        </path>
                                        <path d="M10 12h4"></path>
                                        <path d="M10 7v10v-9"></path>
                                        <path d="M13 7v1"></path>
                                        <path d="M13 16v1"></path>
                                    </svg>
                                </span>
                            <?php else: ?>
                                <span class="nav-link-icon d-md-none d-lg-inline-block">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-help"
                                        width="24" height="24" viewBox="0 0 24 24" stroke-width="2"
                                        stroke="currentColor" fill="none" stroke-linecap="round"
                                        stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                        <circle cx="12" cy="12" r="9"></circle>
                                        <line x1="12" y1="17" x2="12" y2="17.01">
                                        </line>
                                        <path d="M12 13.5a1.5 1.5 0 0 1 1 -1.5a2.6 2.6 0 1 0 -3 -4"></path>
                                    </svg>
                                </span>
                            <?php endif; ?>
                        </div>
                        <form action="<?php echo e(route('dashboard.products.store')); ?>" method="post"
                            enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('post')); ?>

                            
                            <div class="card-body">
                                <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="col-sm-12 m-1 d-none">
                                    <input type="hidden" value="<?php echo e($type); ?>" name="type">
                                    <label class="form-label required"><?php echo e(display('type')); ?></label>
                                    <div>
                                        <select class="form-select" name="type_id">
                                            <option value="">chooes</option>
                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e($product_type->name == $type ? 'selected' : ''); ?>

                                                    value="<?php echo e($product_type->id); ?>"><?php echo e(display($product_type->name)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <?php if($type == 'helper'): ?>
                                    <div class="col-sm-12 m-1 <?php echo e($type == 'helper' ? '' : 'd-none'); ?>">
                                        <label class="form-label required"><?php echo e(display('helper')); ?></label>
                                        <div>
                                            <select class="form-select" name="helper_id">
                                                <option value="">chooes</option>
                                                <?php $__currentLoopData = $helpers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $helper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($helper->id); ?>"><?php echo e(display($helper->name)); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="form-group mb-3 col-md-12 d-flex">
                                    <div class="col-sm-12 m-1">
                                        <label
                                            class="form-label required"><?php echo e(display('quantity products ' . $type)); ?></label>
                                        <div>
                                            <input type="text" class="form-control" name="quantity" value="2"
                                                placeholder="Enter quantity products">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mb-3 col-md-12 d-flex">
                                    <div class="col-sm-12 m-1">
                                        <label
                                            class="form-label required"><?php echo e(display('price products ' . $type)); ?></label>
                                        <div>
                                            <input type="number" class="form-control" name="price" value="100"
                                                placeholder="Enter price products ">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mb-3 ">
                                    <label class="form-label required"><?php echo e(display('image helpers')); ?></label>
                                    <div>
                                        <input type="file" class="form-control" name="image">
                                    </div>
                                </div>
                            </div>



                            
                            <div class="modal-footer">
                                <button type="button" class="btn me-auto"
                                    data-bs-dismiss="modal"><?php echo e(display('Close')); ?></button>
                                <button type="submit" class="btn btn-primary"
                                    data-bs-dismiss="modal"><?php echo e(display('Save')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/dashboard/products/create.blade.php ENDPATH**/ ?>