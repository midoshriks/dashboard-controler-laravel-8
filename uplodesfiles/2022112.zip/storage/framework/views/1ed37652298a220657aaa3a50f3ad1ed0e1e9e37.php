<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <!-- Page title -->
        
        <?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="page-header d-print-none">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <div class="page-pretitle">
                        <img src="<?php echo e(asset('dashboard/src/static/smart_logo.png')); ?>" width="60" alt="" srcset="">
                        <?php echo e(display('Smart bucks')); ?>

                    </div>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><?php echo e(display('Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(route('dashboard.orders.index')); ?>"><?php echo e(display('Order')); ?></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(display('Data orders tables')); ?></li>
                        </ol>
                    </nav>
                </div>
                <!-- Page title actions -->
            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="container-xl">
            <div class="row row-cards">
                <div class="col-12">
                    <div class="card">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-vcenter card-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(display('No.Orders')); ?></th>
                                        <th><?php echo e(display('name users')); ?></th>
                                        <th><?php echo e(display('payment')); ?></th>
                                        <th><?php echo e(display('product')); ?></th>
                                        <th><?php echo e(display('type')); ?></th>
                                        <th><?php echo e(display('amount')); ?></th>
                                        <th><?php echo e(display('total')); ?></th>
                                        <th><?php echo e(display('action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($order->order_numper); ?></td>
                                            <td><?php echo e($order->users->first_name); ?></td>
                                            <td><?php echo e($order->type_method->name); ?></td>
                                            
                                            <td>
                                                
                                                <?php if($order->products->helper_id == null): ?>
                                                    <div class="datagrid-item">
                                                        <div class="datagrid-content">
                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                class="icon icon-tabler icon-tabler-coin-bitcoin"
                                                                width="24" height="24" viewBox="0 0 24 24"
                                                                stroke-width="2" stroke="currentColor" fill="none"
                                                                stroke-linecap="round" stroke-linejoin="round">
                                                                <path stroke="none" d="M0 0h24v24H0z" fill="none">
                                                                </path>
                                                                <circle cx="12" cy="12" r="9">
                                                                </circle>
                                                                <path
                                                                    d="M9 8h4.09c1.055 0 1.91 .895 1.91 2s-.855 2 -1.91 2c1.055 0 1.91 .895 1.91 2s-.855 2 -1.91 2h-4.09">
                                                                </path>
                                                                <path d="M10 12h4"></path>
                                                                <path d="M10 7v10v-9"></path>
                                                                <path d="M13 7v1"></path>
                                                                <path d="M13 16v1"></path>
                                                            </svg>
                                                            <span
                                                                class="status status-yellow"><?php echo e($order->products->type->name); ?></span>
                                                        </div>
                                                    </div>
                                                <?php else: ?><div class="datagrid-item">
                                                        <div class="datagrid-content">
                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                class="icon icon-tabler icon-tabler-help" width="24"
                                                                height="24" viewBox="0 0 24 24" stroke-width="2"
                                                                stroke="currentColor" fill="none" stroke-linecap="round"
                                                                stroke-linejoin="round">
                                                                <path stroke="none" d="M0 0h24v24H0z" fill="none">
                                                                </path>
                                                                <circle cx="12" cy="12" r="9">
                                                                </circle>
                                                                <line x1="12" y1="17" x2="12"
                                                                    y2="17.01">
                                                                </line>
                                                                <path d="M12 13.5a1.5 1.5 0 0 1 1 -1.5a2.6 2.6 0 1 0 -3 -4">
                                                                </path>
                                                            </svg>
                                                            <span
                                                                class="status status-vk"><?php echo e($order->products->helper->name); ?></span>

                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($order->type->name == 'confirm'): ?>
                                                    <div class="datagrid-item">
                                                        <div class="datagrid-content">
                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                class="icon icon-tabler icon-tabler-check" width="24"
                                                                height="24" viewBox="0 0 24 24" stroke-width="2"
                                                                stroke="currentColor" fill="none" stroke-linecap="round"
                                                                stroke-linejoin="round">
                                                                <path stroke="none" d="M0 0h24v24H0z" fill="none">
                                                                </path>
                                                                <path d="M5 12l5 5l10 -10"></path>
                                                            </svg>
                                                            <span
                                                                class="status status-green"><?php echo e($order->type->name); ?></span>
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="datagrid-item">
                                                        <div class="datagrid-content">
                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                class="icon icon-tabler icon-tabler-hourglass"
                                                                width="24" height="24" viewBox="0 0 24 24"
                                                                stroke-width="2" stroke="currentColor" fill="none"
                                                                stroke-linecap="round" stroke-linejoin="round">
                                                                <path stroke="none" d="M0 0h24v24H0z" fill="none">
                                                                </path>
                                                                <path d="M6.5 7h11"></path>
                                                                <path d="M6.5 17h11"></path>
                                                                <path
                                                                    d="M6 20v-2a6 6 0 1 1 12 0v2a1 1 0 0 1 -1 1h-10a1 1 0 0 1 -1 -1z">
                                                                </path>
                                                                <path
                                                                    d="M6 4v2a6 6 0 1 0 12 0v-2a1 1 0 0 0 -1 -1h-10a1 1 0 0 0 -1 1z">
                                                                </path>
                                                            </svg>
                                                            <span
                                                                class="status status-red"><?php echo e($order->type->name); ?></span>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            
                                            
                                            <td> <?php echo e($order->amount); ?> </td>
                                            <td> <?php echo e($order->total); ?> </td>
                                            <td>
                                                <div class="mb-3">
                                                    <label class="form-check form-switch">
                                                        <!-- Rounded switch -->
                                                        <label class="switch">
                                                            <input class="form-check-input btn-active" type="checkbox"
                                                                <?php echo e($order->type->name == 'confirm' ? 'checked' : ''); ?>

                                                                data-form-id="order-active-<?php echo e($order->id); ?>"
                                                                data-name-item="<?php echo e($order->order_numper); ?>">
                                                        </label>

                                                        <form id="order-active-<?php echo e($order->id); ?>" style="display: none"
                                                            action="<?php echo e(route('dashboard.order.active', $order->id)); ?>"
                                                             method="POST"
                                                            style="display: inline-block;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <input name="type_id"
                                                                value="<?php echo e($order->type->name == 'confirm' ? 9 : 10); ?>">
                                                            <input type="submit" value="save">
                                                        </form>
                                                    </label>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\work mido\workgaming\resources\views/dashboard/orders/index.blade.php ENDPATH**/ ?>